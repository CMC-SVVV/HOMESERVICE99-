-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 11, 2019 at 09:06 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `registration`
--

-- --------------------------------------------------------

--
-- Table structure for table `shops`
--

CREATE TABLE `shops` (
  `sno` bigint(5) NOT NULL,
  `name` varchar(200) NOT NULL,
  `address` varchar(200) NOT NULL,
  `number` bigint(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shops`
--

INSERT INTO `shops` (`sno`, `name`, `address`, `number`) VALUES
(17, 'LOTUS ELECTRONICS', 'VIJAY NAGAR', 52010),
(18, 'VINAYAK ELECTRICS', 'INDORE', 66542144);

-- --------------------------------------------------------

--
-- Table structure for table `shopsh`
--

CREATE TABLE `shopsh` (
  `sno` bigint(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `address` varchar(200) NOT NULL,
  `Pno` bigint(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shopsh`
--

INSERT INTO `shopsh` (`sno`, `name`, `address`, `Pno`) VALUES
(11, 'ATITHI DECORS', 'PALASIYA', 9752510493);

-- --------------------------------------------------------

--
-- Table structure for table `shopsp`
--

CREATE TABLE `shopsp` (
  `sno` bigint(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `address` varchar(200) NOT NULL,
  `Pno` bigint(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shopsp`
--

INSERT INTO `shopsp` (`sno`, `name`, `address`, `Pno`) VALUES
(3, 'PLUMBING DOCTOR', 'DADAR', 452010);

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `First Name` varchar(30) NOT NULL,
  `Last Name` varchar(30) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Mobile No.` varchar(15) NOT NULL,
  `Password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`First Name`, `Last Name`, `Email`, `Mobile No.`, `Password`) VALUES
('', '', '', 'ytugu', '123456'),
('', '', '', 'ytugu', '123456'),
('', '', '456', 'fhgjkl', '123456'),
('', '', 'dgfhk', '45', 'rdytfhyjghk'),
('', '', 'rdfjgh', '54', '456'),
('', '', 'ghjk', '543', 'ghj'),
('fghjk', 'fhjg', 'fghjk', '53', '453'),
('Shishir', 'yadav', 'shishir12@outlook.com', '21456378', '12345678'),
('Somitra', 'Singh', 'somitra12@gmail.com', '9752510492', 'windows10'),
('Shishir', 'Yadav', 'ydvshishir@gmail.com', '97452510493', 'windows10'),
('Siddharth', 'Yadav', 'sid981@gmail.com', '8770385406', 'sid98'),
('Vibhore', 'Yadav', 'vibhore1@gmail.com', '44556677', 'windows10'),
('Vibhore', 'Yadav', 'vibhore1@gmail.com', '44556677', 'windows10');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `shops`
--
ALTER TABLE `shops`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `shopsh`
--
ALTER TABLE `shopsh`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `shopsp`
--
ALTER TABLE `shopsp`
  ADD PRIMARY KEY (`sno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `shops`
--
ALTER TABLE `shops`
  MODIFY `sno` bigint(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `shopsh`
--
ALTER TABLE `shopsh`
  MODIFY `sno` bigint(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `shopsp`
--
ALTER TABLE `shopsp`
  MODIFY `sno` bigint(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
