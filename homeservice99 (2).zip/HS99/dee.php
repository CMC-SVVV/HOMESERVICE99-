<?php

		$link=mysqli_connect('localhost','root','','registration');
$a=$_GET['sno'];
$q="delete from shops where sno='$a'";
$q1=mysqli_query($link,$q);
header("location:electronics.php");
?>
