<!DOCTYPE html>
<!DOCTYPE html>
<html>
<head>
	<title>SHOP ENTRY</title>
</head>
<body>
		<?php
	$fm=$_POST['sn'];
	$pn=$_POST['cn'];
	$add=$_POST['address'];

if(isset($_POST['s']))
	{
		$link=mysqli_connect('localhost','root','','registration');
		$qry="insert into shopsp values('','$fm','$add','$pn')";
		mysqli_query($link,$qry);
		header ("location:plumbing.php");
	}
	?>

</body>
</html>