<?php
session_start();
$link=mysqli_connect("localhost","root","","registration");
if(isset($_POST['submit']))
{
		$FirstName=$_POST['First'];
		$LastName=$_POST['Last'];
        $Email=$_POST['Email'];
        $MobileNo=$_POST['MobileNo'];
		$Password=$_POST['Password'];
		
	
		$query="insert into signup values('$FirstName','$LastName','$Email','$MobileNo','$Password')";
		mysqli_query($link,$query);
		
}

if(isset($_POST['login']))
{
$email=$_POST['t1'];
$pass=$_POST['t2'];
$q="select * from signup where Email = '$email'";
$result=mysqli_query($link,$q);
	$row=mysqli_fetch_array($result);
if($email==null && $pass==null)
{
echo"enter something";
}
	
else if($row["Email"]==$email && $row["Password"]==$pass)
{
header ("location:index2.php");
}
else
{
echo"invalid user";
}
	
}	
	
?>

<!DOCTYPE html>
<html>

<head>
  <!-- BASICS -->
  <meta charset="utf-8">
  <title>HOME SERVICE 99 - Your satisfaction is our priority</title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="js/rs-plugin/css/settings.css" media="screen">
  <link rel="stylesheet" type="text/css" href="css/isotope.css" media="screen">
  <link rel="stylesheet" href="css/flexslider.css" type="text/css">
  <link rel="stylesheet" href="js/fancybox/jquery.fancybox.css" type="text/css" media="screen">
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Noto+Serif:400,400italic,700|Open+Sans:300,400,600,700">

  <link rel="stylesheet" href="css/style.css">
  <!-- skin -->
  <link rel="stylesheet" href="skin/default.css">
  <!-- =======================================================
    Theme Name: Vlava
    Theme URL: https://bootstrapmade.com/vlava-free-bootstrap-one-page-template/
    Author: BootstrapMade.com
    Author URL: https://bootstrapmade.com
  ======================================================= -->

  <style type="text/css">
.auto-style1 {
	font-size: large;
}
  .auto-style2 {
	  display: flex;
	  flex-direction: column;
	  align-items: center;
	  font-size: large;
  }
  .auto-style3 {
	z-index: 9999;
	font-size: xx-large;
	color: #000000;
	margin-left: -15px;
	margin-right: -15px;
}
.auto-style4 {
	font-size: x-small;
}
.auto-style5 {
	margin-left: 54px;
}
.auto-style6 {
	margin-left: 107;
}
  .auto-style7 {
	  margin-top: 10px;
	  margin-left: 0;
  }
  .auto-style8 {
	  z-index: 9999;
	  text-align: center;
	  margin-left: -15px;
	  margin-right: -15px;
	  margin-top: 44px;
  }
  .auto-style9 {
	  margin-top: 0px;
  }
  .auto-style10 {
	  font-size: xx-large;
  }
  </style>

</head>

<body>
  <section  class="appear"></section>
  <div class="navbar navbar-fixed-top" role="navigation" data-0="line-height:100px; height:100px; background-color:rgba(0,0,0,0.3);" data-300="line-height:60px; height:60px; background-color:rgba(5, 42, 62, 1);">
    <div class="container">
      
		<form method="post">
			<br>
		</form>
		</ul>
      </div>
      <!--/.navbar-collapse -->
    </div>
  </div>

  <section id="intro">
    <div class="intro-content">
      <h2 class="auto-style1">JOIN OUR MAILING LIST!</h2>
          </div>
  </section>

  <!-- services -->
  <section id="section-services" class="section pad-bot30 bg-white">
    <div class="container">

      <div class="row mar-bot40">
<form  method="post" ">
      	<input class="auto-style6" name="t1" style="width: 438px; height: 44px" type="text" placeholder="Email"><input class="auto-style5" name="t2" style="width: 310px; height: 44px" type="password" placeholder="Password">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		  
			  <input name="login" style="width: 116px; height: 26px" type="submit" value="SUBMIT"></form>
		</div>
    </div>
  </section>
  <span class="auto-style1">

  <p>&nbsp;</p>

  <!-- spacer section:testimonial -->
  <section id="testimonials" class="section" data-stellar-background-ratio="0.5">
    <div class="container">
      <div class="row">
  <span class="auto-style1">

      <div class="auto-style3">

      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		  <span class="auto-style4">If already an member?</span>&nbsp; LOG IN</div>
                    	</span>
                    	</span>

      </div>
    </div>
  </section>

  <!-- about -->
  <section id="section-about" class="section appear clearfix">
    <div class="container">
    <form action="#" method="post" ">
      <div class="row mar-bot40">
      	<input name="First" style="width: 307px; height: 38px" type="text" placeholder="First Name">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		  <input  name="Last" style="width: 336px; height: 37px" type="text" placeholder="Last Name"></div>

      <div class="row align-left mar-bot40">
      	
			<input class="auto-style7" name="Email" style="width: 465px; height: 37px" type="text" placeholder="Email"><div class="auto-style8" style="height: 316px; width: 349px;">
              &nbsp;<span class="auto-style1"><input class="auto-style9" name="MobileNo" style="width: 311px; height: 37px" type="text" placeholder="Mobile No."><br>
				<br><br><br>
			</span>
				<input name="Password" style="width: 307px; height: 38px" type="password" placeholder="Password"><br>
				<br><br><br>
				<input name="submit" style="width: 162px" type="submit" value="SUBMIT"><br></div>
			</form>
      </div>

    </div>
  </section>
  <!-- /about -->

  <!-- spacer section:stats -->

  <!-- section works -->
  <section id="clients" class="section clearfix bg-white">
    <div class="container">
      <div class="row">
          <span class="auto-style1">
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		  </span>
          <span class="auto-style4">
      	New User?</span><span class="auto-style1">
      </span>
          <span class="auto-style10">
      &nbsp;SIGN UP</div>
    </div>
  	  </span>
          <span class="auto-style1">
  	<form method="post">
	  </form>
  </section>

  <!-- contact -->
  <section id="section-contact" class="section appear clearfix">
    <div class="container">

      <div class="row mar-bot40">
          <span class="auto-style1">
      </div>

    </div>
  </section>

  <section id="footer" class="section footer">
    <div class="container">
      <div class="row animated opacity mar-bot20" data-andown="fadeIn" data-animation="animation">
        <div class="col-sm-12 align-center">
          <ul class="social-network social-circle">
            <li><a href="#" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
            <li><a href="#" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
             <li><a href="#" class="icoGoogle" title="Google +"><i class="fa fa-google-plus"></i></a></li>

            <li></li>
          </ul>
        </div>
      </div>
      <div class="row align-center mar-bot20">
        <ul class="footer-menu">
          <li></li>
        </ul>
      </div>
    <div class="row align-center copyright">
        <div class="col-sm-12">
          <p>Copyright &copy; All rights reserved</p>
        </div>
      </div>
      <div class="credits">
  </span>

</body>

</html>

