<?php

		$link=mysqli_connect('localhost','root','','registration');
	$a=$_GET['sno'];
	
	$q="select * from shopsp where sno='$a'";
	$q1=mysqli_query($link,$q);

	if($a=mysqli_fetch_array($q1))
	{
	?>
	<form action="#" method="post">
		
		<h1 align=center>SHOPS DETAILS UPDATION</h1>
	


 
		<table>
		<tr>	
        <td>FULL NAME<td><?php echo"<input type='text' name='sn' value='$a[1]'>"; ?><br>
		</tr><tr>
		<td>ADDRESS<td><?php echo"<input type='text' name='address' value='$a[2]'>";?><br>
		</tr><tr>
		<td>PHONE NUMBER<td><?php echo"<input type='text' name='cn' value='$a[3]'>";?><br>
		</tr>
		<tr><td><input type="submit" name="s" value="UPDATE"></td></tr>
		</table>
		

</form>

<?php


if(isset($_POST['s']))
{
//echo "hello";
$fm=$_POST['sn'];
$add=$_POST['address'];
$pn=$_POST['cn'];




$link=mysqli_connect('localhost','root','','registration');
$q="update shopsp set name='$fm',address='$add',Pno='$pn' where sno='$a[0]'";
$h=mysqli_query($link,$q);
header("location:plumbing.php");


}
?>	


<?php
}


?>
