<!DOCTYPE html>
<!DOCTYPE html>
<html>
<head>
	<title>SHOP ENTRY</title>
</head>
<body>
		<?php
	$fm=$_POST['sn'];
	$pn=$_POST['cn'];
	$add=$_POST['address'];

if(isset($_POST['s']))
	{
		$link=mysqli_connect('localhost','root','','registration');
		$qry="insert into shops values('','$fm','$add','$pn')";
		mysqli_query($link,$qry);
		header ("location:electronics.php");
	}
	?>

</body>
</html>