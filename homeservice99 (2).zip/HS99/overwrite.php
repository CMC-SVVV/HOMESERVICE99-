
	<?php
	$fm=$_POST['name'];
	$add=$_POST['address'];
	$no=$_POST['number'];
	if(isset($_POST['s']))
	{
		$link=mysqli_connect('localhost','root','','shops');
		$qry="insert into d1 values('','$fm','$add','$no')";
		mysqli_query($link,$qry);
	}
	?>
<?php
		$link=mysqli_connect('localhost','root','','shops');	
$q="select * from d1";
$q1=mysqli_query($link,$q);

while($a=mysqli_fetch_array($q1))
{
	echo "<tr>";
	echo "<td>";
	echo $a[1];
	echo "</td>";
echo "<td>";
	echo $a[2];
	echo "</td>";
	echo "<td>";
echo '<a href="de.php?sno='.$a[0].'">';
echo "Delete";
echo '</a>';
echo "</td>";
	echo "<td>";
echo '<a href="up.php?sno='.$a[0].'">';
echo "Update";
echo '</a>';
echo "</td>";

	echo "</tr>";
}
?>
