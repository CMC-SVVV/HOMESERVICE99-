<html>
<head>
<title>LOGIN FORM</title>
<style>
td {
    padding: 7px;
font-family:Comic Sans MS;
}

#txt{
 font-size: 13pt;
    height: 40px;
    border-radius: 15px 50px;
    background: white;
font-family:Comic Sans MS;
       
    }
#tx{
 font-size: 8pt;
    height: 30px;
    border-radius: 15px 50px;
    background: white;
font-family:Comic Sans MS;
}
#butt{

 font-size: 10pt;
    height: 30px;
    border-radius: 15px 50px;
    background: #808080;
font-family:Comic Sans MS;
}
.auto-style1 {
	font-size: large;
}
.auto-style2 {
	font-size: x-large;
}
</style>
<script>
function validate()
{ 
var FirstName = document.register.FirstName.value;
var LastName = document.register.LastName.value;
var MobileNo= document.register.MobileNo.value; 
var Email = document.register.Email.value;
var Password= document.register.Password.value;
if (FirstName==null || FirstName=="")
{ 
alert("Full Name can't be blank"); 
return false; 
}
else if (LastName==null ||LastName=="")
{ 
alert("Email can't be blank"); 
return false; 
}
else if (MobileNo==null ||MobileNo=="")
{ 
alert("Username can't be blank"); 
return false; 
}
else if (Email==null ||Email=="")
{ 
alert("Username can't be blank"); 
return false; 
}
else if(Password.length&amp;lt;6)
{ 
alert("Password must be at least 6 characters long."); 
return false; 
}  
} 
</script>
</head>

<body background="sc.jpg">
<form action="#" method="post" ">

<table width="200%">
<tr>
<td><div><span class="auto-style1"><strong>INDORE TOURISM</strong></span><strong></div></td>
<td><strong>Email
<input type="text" id="tx" name="Emails" placeholder="  Email" width="10" height="10">&nbsp &nbsp &nbsp
 <strong>Password 
<input type="password" id="tx" name="Passwords" placeholder="  Password" size="20">&nbsp &nbsp &nbsp<input type="submit" id="butt" name="login" value=" Login "></td>

</tr>
</form>

<form action="#" method="post" ">
<table align="right">

<tr><th>
<h1 style="font-family:Comic Sans MS;">Create your account
 </th></tr>
<tr>
<td><input type="text" id="txt" name="FirstName" placeholder="  First name" width="10" height="10"></td>
<td><input type="text" id="txt" name="LastName" placeholder="  Last name"></td>
</tr>
<tr>
<td colspan="2"><input type="number" id="txt" name="MobileNo" placeholder="  Enter Mobile number"></td><br>
</tr>
<tr>
<td colspan="2"><input type="text" id="txt" name="Email" placeholder="  Enter Email address" size="20"></td><br>
</tr>
<tr>
<td colspan="2"><input type="password" id="txt" name="Password" placeholder="  New password"></td><br>
</tr>
<tr>
<td><strong><span class="auto-style2">BirthDate</td></span>
</tr>
<tr>
<td><input type="date" id="txt" name="Date" ></td>
</tr>
<tr>
<td>
<center>
<input type="submit" id="butt" name="submit" value="  Sign Up  ">
</center>
</td>
</tr>
</h1>
</div>
</form>
</body>
</html>
<?php
session_start();
$link=mysqli_connect("localhost","root","","indore");
if(isset($_POST['submit']))
{
		$FirstName=$_POST['FirstName'];
		$LastName=$_POST['LastName'];
        $MobileNo=$_POST['MobileNo'];
		$Email=$_POST['Email'];
		$Password=$_POST['Password'];
		$Date=$_POST['Date'];
	
		$query="insert into tourisms values('$FirstName','$LastName','$MobileNo','$Email','$Password','$Date')";
		mysqli_query($link,$query);
		
}

if(isset($_POST['login']))
{
$email=$_POST['Emails'];
$pass=$_POST['Passwords'];
$q="select * from tourisms where Email = '$email'";
$result=mysqli_query($link,$q);
	$row=mysqli_fetch_array($result);
if($email==null && $pass==null)
{
echo"enter something";
}
	
else if($row["Email"]==$email && $row["Password"]==$pass)
{
header("location:saksham tourism.php");
}
else
{
echo"invalid user";
}
	
}	
	
?>



