<!DOCTYPE html>
<html>

<head>
  <!-- BASICS -->
  <meta charset="utf-8">
  <title>HOME SERVICE 99 - Your satisfaction is our priority</title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="js/rs-plugin/css/settings.css" media="screen">
  <link rel="stylesheet" type="text/css" href="css/isotope.css" media="screen">
  <link rel="stylesheet" href="css/flexslider.css" type="text/css">
  <link rel="stylesheet" href="js/fancybox/jquery.fancybox.css" type="text/css" media="screen">
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Noto+Serif:400,400italic,700|Open+Sans:300,400,600,700">

  <link rel="stylesheet" href="css/style.css">
  <!-- skin -->
  <link rel="stylesheet" href="skin/default.css">
  <!-- =======================================================
    Theme Name: Vlava
    Theme URL: https://bootstrapmade.com/vlava-free-bootstrap-one-page-template/
    Author: BootstrapMade.com
    Author URL: https://bootstrapmade.com
  ======================================================= -->

  <style type="text/css">
.auto-style1 {
	font-size: large;
}
  .auto-style2 {
	  display: flex;
	  flex-direction: column;
	  align-items: center;
	  font-size: large;
  }
  .auto-style3 {
	color: #000000;
	font-size: x-large;
}
  </style>

</head>

<body>
  <section id="header" class="appear"></section>
  <div class="navbar navbar-fixed-top" role="navigation" data-0="line-height:100px; height:100px; background-color:rgba(0,0,0,0.3);" data-300="line-height:60px; height:60px; background-color:rgba(5, 42, 62, 1);">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
      	  <span class="fa fa-bars color-white"></span>
        </button>
        <div class="auto-style2">
			<img alt="logo" height="110" src="img/logoHS.png" width="110">
			</div>
      </div>        </ul>
      </div>
      <!--/.navbar-collapse -->
    </div>
  </div>

  <section id="intro">
    <div class="intro-content">
      <h2 class="auto-style1">SHOWING THE BEST CARPENTERS NEAR YOU!</h2>
          </div>
  </section>

  <!-- services -->
  <section id="section-services" class="section pad-bot30 bg-white">
    <div class="container">

     
         <?php
              
     $conn=mysqli_connect('localhost','root','','registration');
     $q="select * from shopsh";
     $q1=mysqli_query($conn,$q);    
 while($a=mysqli_fetch_array($q1))
 {
        echo "<div class='row mar-bot40'>";
       echo "<div class='col-lg-4' style='left: 87px; top: 0px'>";
       echo   "<div class='hi-icon-wrap hi-icon-effect-5 hi-icon-effect-5a mar-top20'>";
           echo "<div class='float-left mar-right20'>";
             echo "<a href='#' class='hi-icon hi-icon-archive' style='font-size: large'>screen</a><span class='auto-style1'>";
		echo		"</span>";
        echo    "</div>";
       echo   "</div>";
    
 echo "<h3 class='auto-style1'>$a[1]</h3>";
 echo "<p class='auto-style1'>$a[2]</p>";
 echo "<p class='auto-style1'>$a[3]</p>";
echo  "<div class='clear'>";
echo  "<a href='uph.php?sno=$a[0]'><input type='submit' name='s' value='UPDATE'>";
echo  "<a href='deh.php?sno=$a[0]'><input type='submit' name='s' value='DELETE'>";
echo "</div>";
echo "</div>";
}
		?>
         


<div class="row mar-bot40">



      </div>
      <div class="row">

      </div>
    </div>
  </section>
  <span class="auto-style1">

  <!-- spacer section:testimonial -->
  <section id="testimonials" class="section" data-stellar-background-ratio="0.5">
    <div class="container">
    <div class="row">
                    	</span>

      				    <strong>

      				  <a href="entryh.php"><input name="Button1" style="width: 176px" type="submit" value="ADD YOUR SHOP"></a></strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="auto-style3"> <strong>&nbsp;You can actually 
						add your shop, Simply by adding some details!</strong></span></div>
    </div>
  </section>
  <!-- /about -->

  <!-- spacer section:stats -->

  <!-- section works -->
  <section id="clients" class="section clearfix bg-white">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="row">
              <span class="auto-style1">
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- contact -->
  <section id="section-contact" class="section appear clearfix">
    <div class="container">

      <div class="row mar-bot40">
          <span class="auto-style1">
      </div>

    </div>
  </section>

  <section id="footer" class="section footer">
    <div class="container">
      <div class="row animated opacity mar-bot20" data-andown="fadeIn" data-animation="animation">
        <div class="col-sm-12 align-center">
          <ul class="social-network social-circle">
            <li><a href="#" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
            <li><a href="#" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
           <li><a href="#" class="icoGoogle" title="Google +"><i class="fa fa-google-plus"></i></a></li>
           <li></li>
          </ul>
        </div>
      </div>
      <div class="row align-center mar-bot20">
        <ul class="footer-menu">
          <li><a href="index2.php">Home</a></li>
          <li><a href="#">About us</a></li>
          <li><a href="regis.php">Get in touch</a></li>
        </ul>
      </div>
      <div class="row align-center copyright">
        <div class="col-sm-12">
          <p>Copyright &copy; All rights reserved</p>
        </div>
      </div>
      <div class="credits">

</body>

</html>
