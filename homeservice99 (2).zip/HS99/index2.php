<!DOCTYPE html>
<html>

<head>
  <!-- BASICS -->
  <meta charset="utf-8">
  <title>HOME SERVICE 99 - Your satisfaction is our priority</title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="js/rs-plugin/css/settings.css" media="screen">
  <link rel="stylesheet" type="text/css" href="css/isotope.css" media="screen">
  <link rel="stylesheet" href="css/flexslider.css" type="text/css">
  <link rel="stylesheet" href="js/fancybox/jquery.fancybox.css" type="text/css" media="screen">
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Noto+Serif:400,400italic,700|Open+Sans:300,400,600,700">

  <link rel="stylesheet" href="css/style.css">
  <!-- skin -->
  <link rel="stylesheet" href="skin/default.css">
  
  <style type="text/css">
.auto-style1 {
	font-size: large;
}
  .auto-style2 {
	  display: flex;
	  flex-direction: column;
	  align-items: center;
	  font-size: large;
  }
  .auto-style3 {
	  margin-left: 0px;
  }
  </style>

</head>

<body>
  <section id="header" class="appear"></section>
  <div class="navbar navbar-fixed-top" role="navigation" data-0="line-height:100px; height:100px; background-color:rgba(0,0,0,0.3);" data-300="line-height:60px; height:60px; background-color:rgba(5, 42, 62, 1);" style="left: 0; right: 0; top: 2px; margin-bottom: 16px">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
      	  <span class="fa fa-bars color-white"></span>
        </button>
        <div class="auto-style2">
			<img alt="logo" height="110" src="img/logoHS.png" width="110" class="auto-style3">
			</div>
      </div
      <div class="navbar-collapse collapse">
        <ul class="nav navbar-nav" data-0="margin-top:20px;" data-300="margin-top:5px;">
          <li class="active"><a href="index2.php" class="auto-style1">Home</a></li>
          <li><a href="#section-about" class="auto-style1">ABOUT</a></li>
          <li><a href="regis.php" class="auto-style1">JOIN Us</a></li>
        </ul>
      </div>
      <!--/.navbar-collapse -->
    </div>
  </div>

  <section id="intro">
    <div class="intro-content">
      <h2 class="auto-style1">SERVICE AT ONE CLICK!</h2>
      <h3 class="auto-style1">MAKE YOUR LIFE EASIER THEN NEVER BEFORE</h3>
     
    </div>
  </section>

  <!-- services -->
  <section id="section-services" class="section pad-bot30 bg-white">
    <div class="container">

      <div class="row mar-bot40">
        <div class="col-lg-4">
          <div class="hi-icon-wrap hi-icon-effect-5 hi-icon-effect-5a mar-top20">
            <div class="float-left mar-right20">
              <a href="electronics.php" class="hi-icon hi-icon-screen" style="font-size: large">screen</a><span class="auto-style1">
				</span>
            </div>
          </div>
          <h3 class="auto-style1">ELECTRONICS</h3>
          <p class="auto-style1">Repair your electronic's items in one click!</p>

          <div class="clear"></div>
        </div>

        <div class="col-lg-4">
          <div class="hi-icon-wrap hi-icon-effect-5 hi-icon-effect-5a mar-top20">
            <div class="float-left mar-right20">
              <a href="homefurniture2.php" class="hi-icon hi-icon-archive" style="font-size: large">location</a><span class="auto-style1">
				</span>
            </div>
          </div>
          <h3 class="auto-style1">HOME FURNITURE</h3>
          <p class="auto-style1">See carpenters near you</p>

          <div class="clear"></div>
        </div>

        <div class="col-lg-4">
          <div class="hi-icon-wrap hi-icon-effect-5 hi-icon-effect-5a mar-top20">
            <div class="float-left mar-right20">
              <a href="plumbing.php" class="hi-icon hi-icon-contract" style="font-size: large">images</a><span class="auto-style1">
				</span>
            </div>
          </div>
          <h3 class="auto-style1">PLUMBING</h3>
          <p class="auto-style1">Best Plumbers near you</p>

          <div class="clear"></div>
        </div>

      </div>
      <div class="row">
          <span class="auto-style1">

      </div>
    </div>
  </section>

  <!-- spacer section:testimonial -->
  <section id="testimonials" class="section" data-stellar-background-ratio="0.5">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="align-center">
            <div class="flexslider testimonials-slider">
              <ul class="slides">
                <li>
                  <div class="testimonial clearfix">
                    <div class="mar-bot20">
                      <img alt="" src="img/testimonial/testimonial1.png" class="img-circle">
                    	</span>
                    </div>
                    <i class="fa fa-quote-left fa-5x"></i>
                    <h5 class="auto-style1">
												Nunc velit risus, dapibus non interdum quis, suscipit nec dolor. Vivamus tempor tempus mauris vitae fermentum. In vitae nulla lacus. Sed sagittis tortor vel arcu sollicitudin nec tincidunt metus suscipit.Nunc velit risus, dapibus non interdum.
											</h5>
                      <span class="auto-style1">
                    <br/>
                      </span>
                    <span class="author"><span class="auto-style1">&mdash; SARAH DOE 
					  </span> <a href="#"><span class="auto-style1">www.siteurl.com</span></a></span><span class="auto-style1">
                  </div>
                </li>

                <li>
                  <div class="testimonial clearfix">
                    <div class="mar-bot20">
                      <img alt="" src="img/testimonial/testimonial2.png" class="img-circle">
                    	</span>
                    </div>
                    <i class="fa fa-quote-left fa-5x"></i>
                    <h5 class="auto-style1">
												Nunc velit risus, dapibus non interdum quis, suscipit nec dolor. Vivamus tempor tempus mauris vitae fermentum. In vitae nulla lacus. Sed sagittis tortor vel arcu sollicitudin nec tincidunt metus suscipit.Nunc velit risus, dapibus non interdum.
												</h5>
                      <span class="auto-style1">
                    <br/>
                      </span>
                    <span class="author"><span class="auto-style1">&mdash; NICOLE DOE 
					  </span> <a href="#"><span class="auto-style1">www.siteurl.com</span></a></span><span class="auto-style1">
                  </div>
                </li>
                <li>
                  <div class="testimonial clearfix">
                    <div class="mar-bot20">
                      <img alt="" src="img/testimonial/testimonial3.png" class="img-circle">
                    	</span>
                    </div>
                    <i class="fa fa-quote-left fa-5x"></i>
                    <h5 class="auto-style1">
											Nunc velit risus, dapibus non interdum quis, suscipit nec dolor. Vivamus tempor tempus mauris vitae fermentum. In vitae nulla lacus. Sed sagittis tortor vel arcu sollicitudin nec tincidunt metus suscipit.Nunc velit risus, dapibus non interdum.
											</h5>
                      <span class="auto-style1">
                    <br/>
                      </span>
                    <span class="author"><span class="auto-style1">&mdash; DASON KRUN 
					  </span> <a href="#"><span class="auto-style1">www.siteurl.com</span></a></span><span class="auto-style1">
					  </span>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>

      </div>
    </div>
  </section>

  <!-- about -->
  <section id="section-about" class="section appear clearfix">
    <div class="container">

      <div class="row mar-bot40">
        <div class="col-md-offset-3 col-md-6">
          <div class="section-header">
            <h2 class="section-heading animated" data-animation="bounceInUp" style="font-size: large">
			Behind HOME SERVICE 99</h2>
            <p><span class="auto-style1">This site is purposed to serve their customers a best quality and healthy service, Fully Garunteed!</p>
          </div>
        </div>
      </div>

      <div class="row align-center mar-bot40">
        <div class="col-md-3">
          <div class="team-member">
            <div class="team-detail">
              <h4 class="auto-style1">ELECTRONICS</h4>
              <span class="auto-style1">Get your home appliances repaired
            </div>
          </div>
        </div>
        <div class="col-md-3" style="left: 125px; top: 1px">
          <div class="team-member">
            <div class="team-detail">
              <h4 class="auto-style1">HOME FURNITURE</h4>
              <span class="auto-style1">Need decored Home?
            </div>
          </div>
        </div>
        <div class="col-md-3" style="left: 159px; top: -3px">
          <div class="team-member">
            <div class="team-detail">
              <h4 class="auto-style1">Plumbing</h4>
              <span class="auto-style1">Get things fixed
            </div>
          </div>
        </div>
          </span>
      </div>

    </div>
  </section>
  <!-- /about -->

  <!-- spacer section:stats -->
  <section id="parallax1" class="section" data-stellar-background-ratio="0.5">
    <div class="container">
      <div class="row appear stats">
        <div class="col-md-3">
          <div class="align-center color-white txt-shadow">
            <div class="icon">
              <i class="fa fa-coffee fa-5x"></i>
            </div>
            <strong id="counter-coffee" class="number" style="font-size: large">50</strong><br class="auto-style1">
            <span class="text" style="font-size: large">mailing lists members</span><span class="auto-style1">
			  </span>
          </div>
        </div>
        <div class="col-md-3">
          <div class="align-center color-white txt-shadow">
            <div class="icon">
              <i class="fa fa-music fa-5x"></i>
            </div>
            <strong id="counter-clock" class="number" style="font-size: large">345</strong><br class="auto-style1">
            <span class="text" style="font-size: large">working hours</span><span class="auto-style1">
			  </span>
          </div>
        </div>
        <div class="col-md-3">
          <div class="align-center color-white txt-shadow">
            <div class="icon">
              <i class="fa fa-clock-o fa-5x"></i>
            </div>
            <strong id="counter-music" class="number" style="font-size: large">3</strong><br class="auto-style1">
            <span class="text" style="font-size: large">services</span><span class="auto-style1">
			  </span>
          </div>
        </div>
        <div class="col-md-3">
          <div class="align-center color-white txt-shadow">
            <div class="icon">
              <i class="fa fa-heart fa-5x"></i>
            </div>
            <strong id="counter-heart" class="number" style="font-size: large">100</strong><br class="auto-style1">
            <span class="text" style="font-size: large">Lovely Clients</span><span class="auto-style1">
			  </span>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- section works -->
  <section id="clients" class="section clearfix bg-white">
    <div class="container">
      <div class="row">
          <span class="auto-style1">
      </div>
    </div>
 
  <!-- contact -->
  <section id="section-contact" class="section appear clearfix">
      <span class="auto-style1">
  </section>

  <section id="footer" class="section footer">
    <div class="container">
      <div class="row animated opacity mar-bot20" data-andown="fadeIn" data-animation="animation">
        <div class="col-sm-12 align-center">
          <ul class="social-network social-circle">
            <li><a href="https://www.facebook.com/homeservice99online/" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
            <li><a href="#" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
            <li><a href="#" class="icoGoogle" title="Google +"><i class="fa fa-google-plus"></i></a></li>
            </ul>
        </div>
      </div>
      <div class="row align-center mar-bot20">
        <ul class="footer-menu">
          <li><a href="#">Home</a></li>
          <li><a href="#">About us</a></li>
          <li><a href="regis.php">Get in touch</a></li>
        </ul>
      </div>
      <div class="row align-center copyright">
        <div class="col-sm-12">
          <p>Copyright &copy; All rights reserved</p>
        </div>
      </div>
      <div class="credits">
         </span>

</body>

</html>
